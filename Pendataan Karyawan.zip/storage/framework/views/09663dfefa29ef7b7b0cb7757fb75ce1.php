<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e($judul ?? 'Dashboard'); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-slate-100">

<header class="bg-blue-900 text-white">
    <div class="mx-auto flex max-w-7xl items-center justify-between px-6 py-5">
        <div>
            <h1 class="text-xl font-bold">
                <?php echo e($judul ?? 'Dashboard'); ?>

            </h1>
            <p class="text-sm text-blue-200">
                Login sebagai: <?php echo e(session('pengguna_nama') ?? auth()->user()->nama_pengguna ?? 'User'); ?>

            </p>
        </div>

        <form action="<?php echo e(route('logout')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <button type="submit" class="rounded-lg bg-white/10 px-4 py-2 text-sm hover:bg-white/20 transition">
                Logout
            </button>
        </form>
    </div>
</header>

<main class="mx-auto max-w-7xl px-6 py-8">
    
    <!-- Bagian Filter & Counter -->
    <div class="mb-6 flex flex-col md:flex-row gap-4 md:items-end justify-between rounded-xl bg-white p-5 shadow">
        
        <!-- Counter -->
        <div>
            <p class="text-sm text-slate-500">Jumlah data ditemukan</p>
            <p class="mt-1 text-3xl font-bold text-blue-800">
                <?php echo e($totalData ?? 0); ?>

            </p>
        </div>

        <!-- Form Filter -->
        <form method="GET" action="<?php echo e(url()->current()); ?>" class="flex flex-col sm:flex-row gap-3 w-full md:w-auto">
            <!-- Pencarian NIK/Nama -->
            <div>
                <input type="text" name="search" value="<?php echo e(request('search')); ?>" placeholder="Cari NIK / Nama..." class="w-full sm:w-48 rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none">
            </div>

            <!-- Filter Departemen: HANYA MUNCUL UNTUK ADMIN HRD -->
            <?php if(isset($mode) && $mode === 'HRD'): ?>
                <div>
                    <select name="departemen" class="w-full sm:w-48 rounded-lg border border-slate-300 px-3 py-2 text-sm focus:border-blue-500 focus:outline-none">
                        <option value="">Semua Departemen</option>
                        <?php $__currentLoopData = $listDepartemen ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($dep); ?>" <?php echo e(request('departemen') == $dep ? 'selected' : ''); ?>>
                                <?php echo e($dep); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            <?php endif; ?>

            <!-- Tombol Aksi -->
            <div class="flex gap-2">
                <button type="submit" class="rounded-lg bg-blue-600 px-4 py-2 text-sm text-white hover:bg-blue-700 transition">
                    Filter
                </button>
                <a href="<?php echo e(url()->current()); ?>" class="rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm text-slate-600 hover:bg-slate-50 transition">
                    Reset
                </a>
                
                <!-- Tombol Unduh CSV hanya untuk Admin HRD -->
                <?php if(isset($mode) && $mode === 'HRD'): ?>
                    <button type="submit" name="export" value="csv" class="rounded-lg bg-green-600 px-4 py-2 text-sm text-white hover:bg-green-700 transition">
                        Unduh CSV
                    </button>
                <?php endif; ?>
            </div>
        </form>
    </div>

    <!-- Tabel Data -->
    <div class="overflow-hidden rounded-xl bg-white shadow">
        <div class="overflow-x-auto">
            <table class="w-full text-left text-sm">
                <thead class="bg-slate-100 text-slate-700 border-b border-slate-200">
                    <tr>
                        <th class="px-4 py-3">No</th>
                        <th class="px-4 py-3">NIK</th>
                        <th class="px-4 py-3">Nama Lengkap</th>
                        <th class="px-4 py-3">Departemen</th>
                        <th class="px-4 py-3">Unit</th>
                        
                        
                        <?php if(isset($mode) && $mode === 'HRD'): ?>
                            <th class="px-4 py-3">Tipe</th>
                        <?php endif; ?>

                        
                        <th class="px-4 py-3">Status Data</th>
                    </tr>
                </thead>

                <tbody class="divide-y divide-slate-200">
                    <?php $__empty_1 = true; $__currentLoopData = $karyawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="hover:bg-slate-50 transition">
                            <td class="px-4 py-3"><?php echo e($karyawan->firstItem() + $index); ?></td>
                            <td class="px-4 py-3"><?php echo e($item->nik_ktp); ?></td>
                            <td class="px-4 py-3 font-semibold">
                                
                                <?php if(isset($mode) && $mode === 'HRD'): ?>
                                    <a href="<?php echo e(route('pendataan.detail', $item->id)); ?>" class="text-blue-600 hover:underline hover:text-blue-800">
                                        <?php echo e($item->nama_lengkap); ?>

                                    </a>
                                <?php else: ?>
                                    <span class="text-slate-800">
                                        <?php echo e($item->nama_lengkap); ?>

                                    </span>
                                <?php endif; ?>
                                <div class="text-xs font-normal text-slate-500">Lahir: <?php echo e($item->tgl_lahir ?? '-'); ?></div>
                            </td>
                            <td class="px-4 py-3"><?php echo e($item->nama_departemen ?? '-'); ?></td>
                            <td class="px-4 py-3"><?php echo e($item->nama_unit ?? '-'); ?></td>
                            
                            <?php if(isset($mode) && $mode === 'HRD'): ?>
                                <td class="px-4 py-3">
                                    <span class="rounded bg-blue-100 px-2 py-1 text-xs font-semibold text-blue-800">
                                        <?php echo e($item->tipe_karyawan ?? 'UMUM'); ?>

                                    </span>
                                </td>
                            <?php endif; ?>

                            <td class="px-4 py-3">
                                <?php if($item->status_verifikasi == 'LENGKAP'): ?>
                                    <span class="text-green-600 font-semibold">Lengkap</span>
                                <?php else: ?>
                                    <span class="text-amber-600 font-semibold">Belum Lengkap</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="<?php echo e((isset($mode) && $mode === 'HRD') ? '7' : '6'); ?>" class="px-4 py-8 text-center text-slate-500">
                                Belum ada data karyawan atau data tidak ditemukan.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <!-- Pagging UI -->
        <?php if($karyawan->hasPages()): ?>
            <div class="border-t border-slate-200 bg-white px-4 py-3">
                <?php echo e($karyawan->links()); ?>

            </div>
        <?php endif; ?>
    </div>
</main>

</body>
</html><?php /**PATH D:\laragon\www\PendataanKaryawan\resources\views/pendataan/dashboard.blade.php ENDPATH**/ ?>