<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lengkapi Data Karyawan - PT Sukun Wartono Indonesia</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    <style>
        [x-cloak]{display:none!important}
        body{background:#eef2f8}
        .lb{display:block;font-size:.875rem;font-weight:600;color:#334155}
        .in{margin-top:.35rem;width:100%;border:1px solid #cbd5e1;border-radius:.5rem;background:#fff;padding:.6rem 1rem;font-size:1rem;color:#0f172a}
        .in:focus{outline:none;border-color:#1d4ed8;box-shadow:0 0 0 3px rgba(29,78,216,.15)}
        .sb{border:1px solid #dbeafe;background:#eff6ff;border-radius:.5rem;padding:1rem}
    </style>
</head>
<body class="text-slate-800 antialiased py-10 px-4">

<div class="max-w-3xl mx-auto bg-white rounded-xl shadow p-6 md:p-8 space-y-6">
    <div>
        <h1 class="text-2xl font-bold text-blue-900">Form Kelengkapan & Perbarui Data Karyawan</h1>
        <p class="text-sm text-slate-500">Silakan perbarui atau lengkapi seluruh data pribadi, keluarga, riwayat pekerjaan, dan administrasi Anda di bawah ini.</p>
    </div>

    <?php if(session('sukses')): ?>
        <div class="rounded-lg bg-emerald-50 p-4 text-emerald-800 text-sm font-semibold border border-emerald-200">
            <?php echo e(session('sukses')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('pendataan.update.token', $karyawan->token)); ?>" method="POST" class="space-y-6" x-data="{ 
        nikah: '<?php echo e($karyawan->status_pernikahan); ?>', 
        anakN: <?php echo e(count($anak ?? [])); ?>,
        sukunN: <?php echo e(max(1, count($riwayatSukun ?? []))); ?>,
        luarN: <?php echo e(max(1, count($pengalaman ?? []))); ?>

    }">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- 1. Informasi Pribadi -->
        <div class="space-y-4 rounded-xl border border-slate-200 p-5 bg-slate-50">
            <h3 class="text-base font-bold text-slate-900 border-b pb-2">1. Informasi Pribadi</h3>
            
            <div>
                <label class="block text-sm font-semibold text-slate-700">Nama Lengkap</label>
                <input type="text" value="<?php echo e($karyawan->nama_lengkap); ?>" disabled class="w-full rounded-lg border bg-slate-200 px-3 py-2 text-sm text-slate-600">
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-semibold text-slate-700">NIK KTP</label>
                    <input type="text" value="<?php echo e($karyawan->nik_ktp); ?>" disabled class="w-full rounded-lg border bg-slate-200 px-3 py-2 text-sm text-slate-600">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-slate-700">NIP (Nomor Induk Pegawai)</label>
                    <input type="text" name="nip" value="<?php echo e($karyawan->nip); ?>" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white" placeholder="Masukkan NIP">
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-semibold text-slate-700">Jenis Kelamin</label>
                    <select name="jenis_kelamin" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white">
                        <option value="L" <?php echo e($karyawan->jenis_kelamin == 'L' ? 'selected' : ''); ?>>Laki-laki</option>
                        <option value="P" <?php echo e($karyawan->jenis_kelamin == 'P' ? 'selected' : ''); ?>>Perempuan</option>
                    </select>
                </div>
                <div>
                    <label class="block text-sm font-semibold text-slate-700">Tanggal Lahir</label>
                    <input type="date" name="tgl_lahir" value="<?php echo e($karyawan->tgl_lahir); ?>" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white">
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-semibold text-slate-700">Golongan Darah</label>
                    <input type="text" name="golongan_darah" value="<?php echo e($karyawan->golongan_darah); ?>" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-slate-700">Disabilitas</label>
                    <input type="text" name="disabilitas" value="<?php echo e($karyawan->disabilitas); ?>" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white" placeholder="- Jika tidak ada">
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-semibold text-slate-700">Pendidikan Terakhir</label>
                    <input type="text" name="pendidikan_terakhir" value="<?php echo e($karyawan->pendidikan_terakhir); ?>" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-slate-700">Jurusan</label>
                    <input type="text" name="jurusan" value="<?php echo e($karyawan->jurusan); ?>" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white">
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-semibold text-slate-700">Nomor WhatsApp / HP</label>
                    <input type="text" name="no_wa" value="<?php echo e($karyawan->no_wa); ?>" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-slate-700">Email</label>
                    <input type="email" name="email" value="<?php echo e($karyawan->email); ?>" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white">
                </div>
            </div>

            <div>
                <label class="block text-sm font-semibold text-slate-700">Alamat Domisili</label>
                <textarea name="alamat_domisili" rows="2" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white"><?php echo e($alamatDom->alamat_lengkap ?? ''); ?></textarea>
            </div>
        </div>

        <!-- 2. Status Keluarga & Anak -->
        <div class="space-y-4 rounded-xl border border-slate-200 p-5 bg-slate-50">
            <h3 class="text-base font-bold text-slate-900 border-b pb-2">2. Status Keluarga & Anak</h3>
            <div>
                <label class="block text-sm font-semibold text-slate-700">Status Pernikahan</label>
                <select name="status_pernikahan" x-model="nikah" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white">
                    <option value="BELUM_KAWIN">Belum menikah</option>
                    <option value="KAWIN">Sudah menikah</option>
                    <option value="CERAI_HIDUP">Cerai hidup</option>
                    <option value="CERAI_MATI">Cerai mati</option>
                </select>
            </div>

            <div x-show="nikah === 'KAWIN'" x-cloak class="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                <div>
                    <label class="block text-sm font-semibold text-slate-700">Nama Suami / Istri (Pasangan)</label>
                    <input type="text" name="nama_pasangan" value="<?php echo e($pasangan->nama_pasangan ?? ''); ?>" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white uppercase">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-slate-700">Pekerjaan Pasangan</label>
                    <input type="text" name="pekerjaan_pasangan" value="<?php echo e($pasangan->pekerjaan_pasangan ?? ''); ?>" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white">
                </div>
            </div>

            <div x-show="nikah !== 'BELUM_KAWIN'" x-cloak class="pt-2">
                <label class="block text-sm font-semibold text-slate-700">Jumlah Anak (maksimal 10)</label>
                <select id="jumlah_anak" name="jumlah_anak" x-model.number="anakN" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white">
                    <option value="0">Tidak ada / 0 anak</option>
                    <template x-for="n in 10" :key="n">
                        <option :value="n" x-text="n + ' anak'"></option>
                    </template>
                </select>
            </div>

            <!-- Daftar Anak Dinamis -->
            <div class="space-y-4 pt-2" x-show="nikah !== 'BELUM_KAWIN' && anakN > 0" x-cloak>
                <template x-for="i in anakN" :key="i">
                    <div class="sb space-y-3 bg-white p-4 rounded-lg border border-slate-200">
                        <p class="text-sm font-semibold text-blue-900" x-text="'Anak ke-' + i"></p>
                        <div>
                            <label class="lb">Nama lengkap anak <span class="text-red-600">*</span></label>
                            <input type="text" :name="'anak[' + i + '][nama_anak]'" :value="getAnakField(i - 1, 'nama_anak')" class="in uppercase" placeholder="Nama Lengkap Anak">
                        </div>
                        <div class="grid gap-4 sm:grid-cols-2">
                            <div>
                                <label class="lb">Tanggal lahir</label>
                                <input type="date" :name="'anak[' + i + '][tgl_lahir_anak]'" :value="getAnakField(i - 1, 'tgl_lahir_anak')" class="in">
                            </div>
                            <div>
                                <label class="lb">Pendidikan / Status</label>
                                <select :name="'anak[' + i + '][pendidikan_anak]'" class="in" x-bind:value="getAnakField(i - 1, 'pendidikan_anak')">
                                    <?php $__currentLoopData = [
                                        'BELUM SEKOLAH'=>'Belum sekolah',
                                        'TK'=>'TK / PAUD',
                                        'SD'=>'SD',
                                        'SMP'=>'SMP',
                                        'SMA/SMK'=>'SMA / SMK',
                                        'KULIAH'=>'Kuliah',
                                        'BEKERJA'=>'Sudah bekerja',
                                    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($v); ?>"><?php echo e($t); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                </template>
            </div>
        </div>

        <!-- 3. Riwayat Pekerjaan di PT. Sukun -->
        <div class="space-y-4 rounded-xl border border-slate-200 p-5 bg-slate-50">
            <div class="flex justify-between items-center border-b pb-2">
                <h3 class="text-base font-bold text-slate-900">3. Riwayat Pekerjaan di PT. Sukun</h3>
                <button type="button" @click="sukunN++" class="px-3 py-1 bg-blue-600 text-white text-xs font-semibold rounded hover:bg-blue-700">+ Tambah Baris</button>
            </div>
            <p class="text-xs text-slate-500">Isi riwayat bagian / unit kerja dan jabatan Anda selama bekerja di lingkungan PT. Sukun Wartono Indonesia.</p>

            <template x-for="i in sukunN" :key="i">
                <div class="sb space-y-3 bg-white p-4 rounded-lg border border-slate-200">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="lb">Bagian / Unit Kerja</label>
                            <input type="text" :name="'riwayat_sukun[' + (i-1) + '][bagian]'" :value="getSukunField(i - 1, 'unit_bagian')" class="in" placeholder="Contoh: Produksi Sigaret">
                        </div>
                        <div>
                            <label class="lb">Jabatan</label>
                            <input type="text" :name="'riwayat_sukun[' + (i-1) + '][jabatan]'" :value="getSukunField(i - 1, 'jabatan')" class="in" placeholder="Contoh: Operator / Staff">
                        </div>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="lb">Tahun Mulai</label>
                            <input type="text" :name="'riwayat_sukun[' + (i-1) + '][tahun_mulai]'" :value="getSukunField(i - 1, 'tgl_mulai')" class="in" placeholder="Contoh: 2020">
                        </div>
                        <div>
                            <label class="lb">Tahun Selesai / Sekarang</label>
                            <input type="text" :name="'riwayat_sukun[' + (i-1) + '][tahun_selesai]'" :value="getSukunField(i - 1, 'tgl_selesai')" class="in" placeholder="Contoh: Sekarang / 2024">
                        </div>
                    </div>
                </div>
            </template>
        </div>

        <!-- 4. Pengalaman Kerja Sebelum di Sukun (Riwayat Luar) -->
        <div class="space-y-4 rounded-xl border border-slate-200 p-5 bg-slate-50">
            <div class="flex justify-between items-center border-b pb-2">
                <h3 class="text-base font-bold text-slate-900">4. Pengalaman Kerja Sebelum di Sukun</h3>
                <button type="button" @click="luarN++" class="px-3 py-1 bg-blue-600 text-white text-xs font-semibold rounded hover:bg-blue-700">+ Tambah Baris</button>
            </div>
            <p class="text-xs text-slate-500">Isi riwayat pekerjaan Anda di perusahaan lain sebelum bergabung dengan PT. Sukun.</p>

            <template x-for="i in luarN" :key="i">
                <div class="sb space-y-3 bg-white p-4 rounded-lg border border-slate-200">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="lb">Nama Perusahaan</label>
                            <input type="text" :name="'riwayat_luar[' + (i-1) + '][perusahaan]'" :value="getLuarField(i - 1, 'nama_perusahaan')" class="in" placeholder="Nama Perusahaan Sebelumnya">
                        </div>
                        <div>
                            <label class="lb">Jabatan</label>
                            <input type="text" :name="'riwayat_luar[' + (i-1) + '][jabatan]'" :value="getLuarField(i - 1, 'jabatan')" class="in" placeholder="Jabatan Terakhir">
                        </div>
                    </div>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="lb">Tahun Masuk</label>
                            <input type="text" :name="'riwayat_luar[' + (i-1) + '][tahun_masuk]'" :value="getLuarField(i - 1, 'tahun_masuk')" class="in" placeholder="Contoh: 2018">
                        </div>
                        <div>
                            <label class="lb">Tahun Keluar</label>
                            <input type="text" :name="'riwayat_luar[' + (i-1) + '][tahun_keluar]'" :value="getLuarField(i - 1, 'tahun_keluar')" class="in" placeholder="Contoh: 2020">
                        </div>
                    </div>
                </div>
            </template>
        </div>

        <!-- 5. Perbankan & Administrasi -->
        <div class="space-y-4 rounded-xl border border-slate-200 p-5 bg-slate-50">
            <h3 class="text-base font-bold text-slate-900 border-b pb-2">5. Perbankan & Administrasi</h3>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-semibold text-slate-700">Nomor Rekening (10 digit BNI / 15 digit BRI)</label>
                    <input type="text" name="no_rekening" value="<?php echo e($karyawan->no_rekening); ?>" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-slate-700">Atas Nama Rekening</label>
                    <input type="text" name="nama_pemilik_rekening" value="<?php echo e($karyawan->nama_pemilik_rekening); ?>" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white uppercase">
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-semibold text-slate-700">No. BPJS Kesehatan</label>
                    <input type="text" name="no_bpjs_kesehatan" value="<?php echo e($karyawan->no_bpjs_kesehatan); ?>" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-slate-700">No. BPJS Ketenagakerjaan</label>
                    <input type="text" name="no_bpjs_ketenagakerjaan" value="<?php echo e($karyawan->no_bpjs_ketenagakerjaan); ?>" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white" placeholder="Nomor BPJS Ketenagakerjaan">
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-semibold text-slate-700">NPWP</label>
                    <input type="text" name="npwp" value="<?php echo e($karyawan->npwp); ?>" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white">
                </div>
                <div>
                    <label class="block text-sm font-semibold text-slate-700">No. Anggota Koperasi</label>
                    <input type="text" name="no_anggota_koperasi" value="<?php echo e($karyawan->no_anggota_koperasi); ?>" class="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm bg-white">
                </div>
            </div>
        </div>

        <div class="pt-4">
            <button type="submit" class="w-full rounded-lg bg-blue-600 px-4 py-3 text-sm font-bold text-white hover:bg-blue-700 transition shadow">
                Simpan Seluruh Perubahan Data
            </button>
        </div>
    </form>
</div>

<script>
const existingAnak = <?php echo json_encode($anak ?? [], 15, 512) ?>;
const existingSukun = <?php echo json_encode($riwayatSukun ?? [], 15, 512) ?>;
const existingLuar = <?php echo json_encode($pengalaman ?? [], 15, 512) ?>;

function getAnakField(index, field) {
    if (existingAnak[index] && existingAnak[index][field]) {
        return existingAnak[index][field];
    }
    return '';
}

function getSukunField(index, field) {
    if (existingSukun[index] && existingSukun[index][field]) {
        return existingSukun[index][field];
    }
    return '';
}

function getLuarField(index, field) {
    if (existingLuar[index] && existingLuar[index][field]) {
        return existingLuar[index][field];
    }
    return '';
}
</script>

</body>
</html><?php /**PATH D:\laragon\www\PendataanKaryawan\resources\views/pendataan/edit-token.blade.php ENDPATH**/ ?>